INSERT INTO book VALUES(1, 'ISBN1', 'Author1', 5.5, 'title1');
INSERT INTO book VALUES(2, 'ISBN2', 'Author2', 10.10, 'title1');