INSERT INTO Car VALUES( 2, 'Silver', 'Volvo', 'S80', 1999);
INSERT INTO Car VALUES(1, 'Red', 'Honda', 'Accord', 1997);

INSERT INTO Book (id,isbn,author,price,title) VALUES(1,'12345','Uncle Bob','50','CleanCode');
INSERT INTO Book (id,isbn,author,price,title) VALUES(2,'567898','Jeams Clear','100','Effective Java');

